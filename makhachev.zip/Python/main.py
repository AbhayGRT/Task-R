import streamlit as st
import os
import json
from datetime import datetime
import subprocess
import shutil
import requests

st.set_page_config(page_title="Makhachev",page_icon = "favicon.ico", layout="wide")

API_URL = "https://makhachev.vercel.app/"

def fetch_and_update_data():
    """Fetches the latest data from the API and updates data.json, then reloads it."""
    try:
        response = requests.get(API_URL)
        if response.status_code == 200:
            new_data = response.json()
            with open('data.json', 'w') as f:
                json.dump(new_data, f, indent=4)
            st.session_state["data"] = new_data
            st.success("✅ Data updated successfully!")
            st.rerun()
        else:
            st.error(f"❌ Failed to fetch data. Status code: {response.status_code}")
    except Exception as e:
        st.error(f"❌ Error fetching data: {str(e)}")


if "data" not in st.session_state:
    try:
        with open('data.json', 'r') as f:
            st.session_state["data"] = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        st.error(f"Error loading data.json: {str(e)}")
        st.stop()

data = st.session_state["data"]

client_stg = data.get('client_stg', {})  
client_prod = data.get('client_prod', {})  
dev_name = data.get('dev_name', {})  
clients = data.get('clients', [])  
environments = data.get('environments', [])  
product_person = data.get('product_person', "")  
default_name = data.get('default_name', '')  
server_stg = data.get('server_stg', {})  
server_prod = data.get('server_prod', {})  

def execute_command(command):
    """Executes a shell command and returns its output."""
    try:
        result = subprocess.run(command, shell=True, text=True, capture_output=True, check=True)
        return result.stdout if result.stdout else result.stderr
    except subprocess.CalledProcessError as e:
        return f"Command failed with error: {e.stderr}"
    except Exception as e:
        return str(e)

def create_deployment_app():
    if "output" not in st.session_state:
        st.session_state["output"] = {}
    
    if "uploaded_files" not in st.session_state:
        st.session_state["uploaded_files"] = set()

    with st.sidebar:
        st.header("Update Data")
        if st.button("Fetch Latest Data"):
            fetch_and_update_data()
        
        st.header("Inputs")

        developers = list(dev_name.keys())
        st.success(f"Current name: {default_name}")

        selected_dev = st.selectbox("Select your Name: ", developers, index=developers.index(default_name) if default_name in developers else 0)

        if selected_dev != default_name:
            data['default_name'] = selected_dev
            with open('data.json', 'w') as f:
                json.dump(data, f, indent=4)  
            st.error(f"Current user changed: {selected_dev}")

        st.divider()

        selected_client = st.selectbox("Select Client: ", clients)
        selected_env = st.selectbox("Select Environment: ", environments)
        ticket_input = st.text_input("Enter Ticket Number (eg: 1636): ")
        st.divider()

        deployment_type = st.radio("Select Deployment Type", ["Server Side", "Client Side"])

    if deployment_type == "Server Side":
        handle_server_side(data['default_name'], selected_client, selected_env, ticket_input)
    else:
        handle_client_side(data['default_name'], selected_client, selected_env, ticket_input)
            
    if "output" in st.session_state:
        for key, value in st.session_state["output"].items():
            st.text(f"{key}. {value['label']}")
            st.code(value['command'], language=value['lang'])
                
            if value["lang"] == "bash":
                if st.button(f"Run {value['label']}", key=f"execute_{key}"):
                    output = execute_command(value['command'])
                    st.code(output, language="bash")

def handle_client_side(developer, client, environment, ticket):
    st.title("Client Side Deployment Command")
    st.session_state["output"] = {}

    dev_paths = dev_name[developer]
    full_path = os.path.join(dev_paths['folder_path_build'], 'dist', client, 'client-build', 'development')
    upload_folder = dev_paths['folder_path_upload']
    backup_folder = dev_paths['folder_path_backup']

    ticket_number = f"{client.upper()}-{ticket}" if ticket else "client-" + environment + "-" + client + "-" + datetime.now().strftime("%d-%m-%Y-%H-%M-%S")

    if not os.path.exists(full_path):
        st.error(f"Build path {full_path} does not exist. Please check the path and client selection.")
        return

    build_files = os.listdir(full_path)
    
    existing_uploads = os.listdir(upload_folder) if os.path.exists(upload_folder) else []
    if existing_uploads:
        with st.warning("⚠️ Before selecting files, all previous files in the upload folder will be deleted."):
            if st.button("Please click this to make sure all the previous files will be deleted in the upload folder before selecting any files"):
                for file in existing_uploads:
                    try:
                        os.remove(os.path.join(upload_folder, file))
                    except Exception as e:
                        st.error(f"Failed to delete {file}: {str(e)}")
                st.success("✅ Upload folder cleared! You can now select files.")
    
    st.divider()
                    
    selected_files = st.multiselect("Select files to upload", build_files, key="file_selection")
    
    uploaded_files = st.session_state["uploaded_files"]
    deselected_files = uploaded_files - set(selected_files)

    for file in deselected_files:
        try:
            os.remove(os.path.join(upload_folder, file))
            st.success(f"Removed {file} from the upload folder.")
        except FileNotFoundError:
            pass

    st.session_state["uploaded_files"] = set(selected_files)

    if selected_files:
        os.makedirs(upload_folder, exist_ok=True)
        for file in selected_files:
            if file not in uploaded_files:
                try:
                    shutil.copy(os.path.join(full_path, file), os.path.join(upload_folder, file))
                    st.success(f"Copied {file} to upload folder.")
                except Exception as e:
                    st.error(f"Failed to copy file: {file}. Error: {str(e)}")

    st.divider()
        
    s3_path = client_stg[client] if environment == 'stg' else client_prod[client]
    backup_path = os.path.join(backup_folder, ticket_number)
    os.makedirs(backup_path, exist_ok=True)

    includes = " ".join([f'--include \"{file}\"' for file in selected_files]) if selected_files else ""
    backup_command = f"aws s3 cp {s3_path} {backup_path} --recursive --profile sportz --exclude \"*\" {includes}"

    st.session_state["output"] = {
        "1 ": {"label": "Backup Command", "command": backup_command, "lang": "bash"},
        "2 ": {"label": "Dry Run Command", "command": f"aws s3 cp {upload_folder} {s3_path} --recursive --profile sportz --dryrun", "lang": "bash"},
        "3 ": {"label": "Upload Command", "command": f"aws s3 cp {upload_folder} {s3_path} --recursive --profile sportz", "lang": "bash"},
        "4 ": {"label": "Check Command", "command": f"aws s3 ls {s3_path} --profile sportz", "lang": "bash"},
        "5 ": {"label": "Js Version Up", "command": f"@{product_person[client]} Can you please update js version on {environment} regarding https://sportzinteractive.atlassian.net/browse/{ticket_number}", "lang": "text"},
    }

def handle_server_side(developer, client, environment, ticket):
    s3_path = server_stg[client] if environment == 'stg' else server_prod[client]
    st.title("Server Side Deployment Command")
    st.session_state["output"] = {}

    dev_paths = dev_name[developer]
    backup_folder = dev_paths['folder_path_backup']
    ticket_number = f"{client.upper()}-{ticket}" if ticket else "server-" + environment + "-" + client + "-" + datetime.now().strftime("%d-%m-%Y-%H-%M-%S")
    full_path = os.path.join(dev_paths['folder_path_build'])

    backup_path = os.path.join(backup_folder, ticket_number)
    os.makedirs(backup_path, exist_ok=True)
    
    st.session_state["output"] = {
        "1 ": {"label": "Announcement Command", "command": f"@here deploying {client} SSR on {environment}", "lang": "text"},
        "2 ": {"label": "Server side Command (Tar file Backup)", "command": f"aws s3 cp {s3_path} {backup_path} --profile sportz", "lang": "bash"},
        "3 ": {"label": "Server side Command (Tar file)", "command": f"cd {full_path} && npm run deploy-time", "lang": "bash"}
    }

if __name__ == "__main__":
    create_deployment_app()
