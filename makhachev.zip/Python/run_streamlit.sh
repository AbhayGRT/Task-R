#!/bin/bash

cd ~
echo "Activating virtual environment..."
source si-deployment/bin/activate

cd makhachev

PORT=8501
PID=$(lsof -ti :$PORT)

if [ ! -z "$PID" ]; then
    echo "Port $PORT is already in use. Opening http://localhost:8501..."
        xdg-open "http://localhost:8501" &>/dev/null &
    exit 0
fi

# Run Streamlit app
echo "Starting Streamlit app..."
streamlit run main.py --server.address 0.0.0.0
