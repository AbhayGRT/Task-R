import json
import os
import sys
import socket
from datetime import datetime

with open('data.json', 'r') as f:
    data = json.load(f)

default_name = data.get('default_name', '')
dev_name = data.get('dev_name', {})
branches = data.get('branch', {})
ports_to_check = data.get("ports", [])

if len(sys.argv) < 2:
    print("Usage: python3 run.py <client> <env>  OR  python3 run.py curr")
    sys.exit(1)

arg = sys.argv[1]

folder_path = dev_name[default_name]['folder_path_build']
os.chdir(folder_path)

def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0

def kill_process_on_port(port):
    print(f"⚠️ Port {port} is in use! Killing process...")
    os.system(f"fuser -k {port}/tcp")  # Works on Linux/macOS
    # os.system(f"npx kill-port {port}")  # Alternative for cross-platform

for port in ports_to_check:
    if is_port_in_use(port):
        kill_process_on_port(port)

current_branch = os.popen("git rev-parse --abbrev-ref HEAD").read().strip()

if arg == "curr":
    print(f"📌 Staying on current branch: **{current_branch}**")
else:
    if len(sys.argv) < 3:
        print("Usage: python3 run.py <client> <env>")
        sys.exit(1)

    client = sys.argv[1]
    env = sys.argv[2]

    if client not in branches:
        print(f"Invalid client name! Choose from: {', '.join(branches.keys())}")
        sys.exit(1)

    branch_index = 0 if env == "dev" else 1 if env == "dep" else None
    if branch_index is None:
        print("Invalid environment! Use 'dev' for development or 'dep' for deployment.")
        sys.exit(1)

    git_branch = branches[client][branch_index]

    status_output = os.popen("git status --porcelain").read().strip()
    
    if status_output:
        print(f"⚠️ Uncommitted changes detected on branch: **{current_branch}**")
        action = input("Do you want to (S)tash or (D)iscard changes? [S/D]: ").strip().lower()

        if action == "s":
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            stash_name = f"stash-{current_branch}-{timestamp}"
            os.system(f"git stash push -m '{stash_name}'")
            print(f"✅ Changes stashed as: {stash_name}")

        elif action == "d":
            os.system("git reset --hard")
            print("✅ Changes discarded.")

        else:
            print("❌ Invalid option. Exiting.")
            sys.exit(1)

    os.system(f"git checkout {git_branch}")

os.system("code .")
os.system("npm run dev-nuxt")
